Add your profile photo here as: profile.jpg

Recommended: a square or portrait photo, at least 600x750px, good lighting,
plain background. The site will pick it up automatically — no code changes
needed. Until you add it, the hero section shows a "JA" placeholder instead.
