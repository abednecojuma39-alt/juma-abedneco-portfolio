/* ==========================================================
   1. MOBILE NAV TOGGLE
   Shows/hides the nav panel on small screens and keeps the
   hamburger icon's aria-expanded state in sync for screen readers.
========================================================== */
const navToggle = document.getElementById('nav-toggle');
const mainNav = document.getElementById('main-nav');

navToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(isOpen));
});

// Close the mobile menu after a link is tapped, so the page
// doesn't stay covered by the panel once the user has navigated.
mainNav.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});

/* ==========================================================
   2. HEADER BACKGROUND ON SCROLL
   Adds a solid background + border once the user scrolls past
   the hero, so nav text stays readable over any section.
========================================================== */
const siteHeader = document.getElementById('site-header');

window.addEventListener('scroll', () => {
  siteHeader.classList.toggle('scrolled', window.scrollY > 40);
}, { passive: true });

/* ==========================================================
   3. ACTIVE NAV LINK ON SCROLL
   Uses IntersectionObserver to detect which section is in view
   and highlights the matching link in the nav bar.
========================================================== */
const sections = document.querySelectorAll('main section[id]');
const navLinks = document.querySelectorAll('.nav-link');

const setActiveLink = (id) => {
  navLinks.forEach(link => {
    link.classList.toggle('active-link', link.getAttribute('href') === `#${id}`);
  });
};

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      setActiveLink(entry.target.id);
    }
  });
}, { rootMargin: '-40% 0px -55% 0px' }); // triggers when a section is roughly centred in the viewport

sections.forEach(section => sectionObserver.observe(section));

/* ==========================================================
   4. CONTACT FORM (frontend-only)
   This form has no backend or email service wired up yet, so
   it never claims to "send" anything. It just confirms the
   fields are filled in and points the visitor to a direct email
   in the meantime. Swap this handler out once a real email
   service (e.g. Formspree, EmailJS, or a server endpoint) is
   connected.
========================================================== */
const contactForm = document.getElementById('contact-form');
const formStatus = document.getElementById('form-status');

if (contactForm) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();

    if (!contactForm.checkValidity()) {
      formStatus.textContent = 'Please fill in all fields before sending.';
      formStatus.classList.remove('is-visible');
      return;
    }

    formStatus.textContent =
      'This form isn\u2019t connected to an email service yet — please email abednecojuma39@gmail.com directly in the meantime.';
    formStatus.classList.add('is-visible');
  });
}

/* ==========================================================
   5. FOOTER YEAR
   Keeps the copyright year correct automatically instead of
   relying on a hardcoded number that goes stale.
========================================================== */
const footerYear = document.getElementById('footer-year');
if (footerYear) {
  footerYear.textContent = new Date().getFullYear();
}
